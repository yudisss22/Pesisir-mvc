<?php $__env->startSection('heading', 'Katalog ikan'); ?>
<?php $__env->startSection('subtitle', 'Kelola data ketersediaan ikan yang tampil di halaman Ikan.'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.subnav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="glass-card p-6">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <form method="GET" action="<?php echo e(route('admin.fish.index')); ?>" class="grid flex-1 gap-3 sm:grid-cols-[1fr_12rem_auto]">
                <div>
                    <label for="a-q" class="sr-only">Cari ikan</label>
                    <input id="a-q" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama ikan…" class="field-input">
                </div>
                <div>
                    <label for="a-region" class="sr-only">Wilayah</label>
                    <select id="a-region" name="wilayah" class="field-input">
                        <option value="">Semua wilayah</option>
                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r->value); ?>" <?php if($region === $r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <button type="submit" class="btn-primary px-8 text-sm">Terapkan</button>
            </form>
            <a href="<?php echo e(route('admin.fish.create')); ?>" class="btn-ghost text-sm">+ Tambah ikan</a>
        </div>

        <?php if($fish->isEmpty()): ?>
            <p class="mt-6 rounded-md bg-sky-50 p-6 text-center text-sm text-grey-600">Tidak ada data ikan yang cocok.</p>
        <?php else: ?>
            <div class="mt-5 overflow-x-auto">
                <table class="w-full min-w-[36rem] text-left text-sm">
                    <thead>
                        <tr class="border-b border-grey-100 text-xs font-extrabold uppercase tracking-wide text-grey-600">
                            <th class="py-2 pr-3">Foto</th>
                            <th class="py-2 pr-3">Nama</th>
                            <th class="py-2 pr-3">Wilayah</th>
                            <th class="py-2 pr-3">Kelangkaan</th>
                            <th class="py-2 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $fish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b border-grey-100 align-middle">
                                <td class="py-3 pr-3">
                                    <?php if($f->photoUrl()): ?>
                                        <img src="<?php echo e($f->photoUrl()); ?>" alt="Foto <?php echo e($f->name); ?>" class="h-12 w-12 rounded-md object-cover">
                                    <?php else: ?>
                                        <span class="text-xs text-grey-400">Belum ada</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 pr-3 font-bold"><?php echo e($f->name); ?></td>
                                <td class="py-3 pr-3 text-xs text-grey-700"><?php echo e($f->region->label()); ?></td>
                                <td class="py-3 pr-3"><span class="rounded-full px-3 py-0.5 text-xs font-extrabold <?php echo e($f->rarity->badgeClass()); ?>"><?php echo e($f->rarity->label()); ?></span></td>
                                <td class="py-3 text-right">
                                    <div class="flex justify-end gap-2">
                                        <a href="<?php echo e(route('admin.fish.edit', $f)); ?>" class="rounded-full bg-blue-100 px-3 py-1 text-xs font-extrabold text-blue-600">Ubah</a>
                                        <form method="POST" action="<?php echo e(route('admin.fish.destroy', $f)); ?>" data-confirm="Hapus <?php echo e($f->name); ?> (<?php echo e($f->region->label()); ?>)?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($fish->links()); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/admin/fish/index.blade.php ENDPATH**/ ?>