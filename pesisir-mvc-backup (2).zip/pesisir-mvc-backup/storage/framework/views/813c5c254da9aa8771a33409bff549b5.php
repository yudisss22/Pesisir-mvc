<?php
    $flashStyles = [
        'success' => 'bg-teal-100 text-teal-500',
        'error' => 'bg-red-100 text-danger',
        'warning' => 'bg-amber-100 text-amber-500',
        'info' => 'bg-blue-100 text-blue-600',
    ];
?>
<?php $__currentLoopData = $flashStyles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session($type)): ?>
        <div role="<?php echo e($type === 'error' ? 'alert' : 'status'); ?>" data-flash class="mb-4 flex items-start justify-between gap-3 rounded-md px-4 py-3 text-sm font-bold shadow-card <?php echo e($style); ?>">
            <span><?php echo e(session($type)); ?></span>
            <button type="button" data-flash-close aria-label="Tutup pesan" class="flex-none text-base leading-none">&times;</button>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($errors->any() && ! $errors->hasAny(['whatsapp_number', 'password', 'name', 'title', 'category', 'severity', 'location_id', 'description', 'message', 'area', 'fish_name', 'quantity', 'note', 'image', 'share', 'role', 'agree', 'region', 'rarity', 'image_url', 'status', 'current_password'])): ?>
    <div role="alert" class="mb-4 rounded-md bg-red-100 px-4 py-3 text-sm font-bold text-danger shadow-card">
        Periksa kembali data yang Anda isi.
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/partials/flash.blade.php ENDPATH**/ ?>