<?php $__env->startSection('heading', 'Panel admin'); ?>
<?php $__env->startSection('subtitle', 'Ringkasan statistik aplikasi, sebaran laporan, dan akses cepat ke pengelolaan pengguna serta katalog ikan.'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.subnav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="glass-card mb-5 p-6">
        <h2 class="font-serif text-xl font-bold">Bagikan info pasang surut</h2>
        <p class="mt-1 text-sm text-grey-600">
            Informasi lokasi aktif akan dikirim otomatis melalui WhatsApp kepada user yang memberi persetujuan.
            <?php if (! ($whatsappConfigured)): ?>
                Lengkapi konfigurasi Meta WhatsApp Cloud API di environment server sebelum mengirim.
            <?php endif; ?>
        </p>
        <form method="POST" action="<?php echo e(route('admin.share-information')); ?>" class="mt-4">
            <?php echo csrf_field(); ?>
            <button type="submit" <?php if(! $whatsappConfigured): echo 'disabled'; endif; ?>
                    class="btn-primary disabled:cursor-not-allowed disabled:opacity-50">
                Bagikan ke WhatsApp user
            </button>
        </form>
    </section>

    <div class="grid grid-cols-2 gap-4 md:grid-cols-6">
        <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="glass-card p-4 text-center">
                <p class="font-mono text-3xl font-bold"><?php echo e(number_format($value, 0, ',', '.')); ?></p>
                <p class="mt-1 text-xs font-bold text-grey-600"><?php echo e($label); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-5 grid gap-5 lg:grid-cols-3">
        <?php $__currentLoopData = [['Laporan per status', $statusRows], ['Laporan per kategori', $categoryRows], ['Pengguna per peran', $roleRows]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$title, $rows]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $max = max(1, $rows->max('total')); ?>
            <section class="glass-card p-6">
                <h2 class="font-serif text-lg font-bold"><?php echo e($title); ?></h2>
                <ul class="mt-4 space-y-3">
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="flex justify-between text-xs font-bold"><span><?php echo e($row['label']); ?></span><span class="font-mono"><?php echo e($row['total']); ?></span></div>
                            <div class="mt-1 h-2.5 overflow-hidden rounded-full bg-grey-100">
                                <div class="h-full rounded-full bg-blue-500" style="width: <?php echo e(round($row['total'] / $max * 100)); ?>%"></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-5 grid gap-5 lg:grid-cols-2">
        <section class="glass-card p-6">
            <h2 class="font-serif text-lg font-bold">Lokasi dengan laporan terbanyak</h2>
            <?php if($topLocations->isEmpty()): ?>
                <p class="mt-3 rounded-md bg-sky-50 p-4 text-sm text-grey-600">Belum ada laporan.</p>
            <?php else: ?>
                <ol class="mt-3 space-y-2">
                    <?php $__currentLoopData = $topLocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-center justify-between rounded-md border border-grey-100 bg-white px-4 py-2.5 text-sm">
                            <span class="font-bold"><?php echo e($row->location?->name ?? '-'); ?></span>
                            <span class="font-mono text-xs text-grey-600"><?php echo e($row->total); ?> laporan</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            <?php endif; ?>
        </section>

        <section class="glass-card p-6">
            <div class="flex items-center justify-between">
                <h2 class="font-serif text-lg font-bold">Laporan terbaru</h2>
                <a href="<?php echo e(route('laporan.index')); ?>" class="text-xs font-bold text-blue-600">Lihat semua</a>
            </div>
            <?php if($latestReports->isEmpty()): ?>
                <p class="mt-3 rounded-md bg-sky-50 p-4 text-sm text-grey-600">Belum ada laporan.</p>
            <?php else: ?>
                <ul class="mt-3 space-y-2">
                    <?php $__currentLoopData = $latestReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('laporan.show', $r)); ?>" class="block rounded-md border border-grey-100 bg-white px-4 py-2.5 hover:border-blue-500">
                                <div class="flex items-start justify-between gap-2">
                                    <span class="text-sm font-bold"><?php echo e($r->title); ?></span>
                                    <span class="flex-none rounded-full px-2.5 py-0.5 text-[11px] font-extrabold <?php echo e($r->status->badgeClass()); ?>"><?php echo e($r->status->label()); ?></span>
                                </div>
                                <p class="mt-0.5 text-xs text-grey-400"><?php echo e($r->location->name); ?> · <?php echo e($r->created_at->diffForHumans()); ?></p>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>