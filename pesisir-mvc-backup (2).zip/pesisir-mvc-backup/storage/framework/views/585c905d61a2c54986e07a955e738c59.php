<?php
    $navItems = [
        ['beranda', 'Beranda', 'home', 'beranda'],
        ['prediksi', 'Prediksi', 'wave', 'prediksi'],
        ['ikan.index', 'Ikan', 'fish', 'ikan.*'],
        ['laporan.create', 'Laporan', 'report', 'laporan.*'],
        ['komunitas.index', 'Komunitas', 'people', 'komunitas.*'],
        ['pengaturan.index', 'Setelan', 'gear', 'pengaturan.*'],
    ];
    if (auth()->check() && auth()->user()->isAdmin()) {
        $navItems[] = ['admin.dashboard', 'Admin', 'shield', 'admin.*'];
    }
?>
<nav aria-label="Navigasi utama" class="fixed inset-x-0 bottom-0 z-40 border-t border-grey-100 bg-white md:static md:z-auto md:mx-auto md:mt-4 md:max-w-6xl md:border-0 md:bg-transparent md:px-8">
    <ul class="mx-auto flex max-w-6xl justify-around md:justify-between md:gap-1 md:rounded-lg md:bg-white/90 md:p-2 md:shadow-card">
        <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label, $icon, $pattern]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $active = request()->routeIs($pattern); ?>
            <li class="flex-1">
                <a href="<?php echo e(route($route === 'laporan.create' && auth()->user()?->isAdmin() ? 'laporan.index' : $route)); ?>" <?php if($active): ?> aria-current="page" <?php endif; ?>
                   class="flex flex-col items-center gap-1 px-1 py-2.5 text-[10px] font-bold md:flex-row md:justify-center md:gap-2 md:rounded-md md:text-sm <?php echo e($active ? 'text-blue-600 md:bg-white md:shadow-card' : 'text-navy-800/70 hover:text-blue-600'); ?>">
                    <?php echo $__env->make('partials.icon', ['name' => $icon, 'class' => 'h-5 w-5'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo e($label); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
<?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/partials/nav.blade.php ENDPATH**/ ?>