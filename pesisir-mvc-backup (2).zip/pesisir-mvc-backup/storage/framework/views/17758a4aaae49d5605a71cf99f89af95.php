<?php $editing = $fish->exists; ?>

<?php $__env->startSection('heading', $editing ? 'Ubah data ikan' : 'Tambah ikan'); ?>
<?php $__env->startSection('subtitle', 'Data ini tampil di halaman Ikan sesuai wilayah dan tingkat kelangkaannya.'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.subnav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="glass-card max-w-2xl p-6">
        <a href="<?php echo e(route('admin.fish.index')); ?>" class="text-sm font-bold text-blue-600">&larr; Batal</a>

        <form method="POST" action="<?php echo e($editing ? route('admin.fish.update', $fish) : route('admin.fish.store')); ?>" enctype="multipart/form-data" novalidate class="mt-4 space-y-4">
            <?php echo csrf_field(); ?>
            <?php if($editing): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div>
                <label for="name" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Nama ikan</label>
                <input id="name" type="text" name="name" value="<?php echo e(old('name', $fish->name)); ?>" class="field-input mt-1.5 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo $__env->make('partials.field-error', ['name' => 'name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div class="grid gap-4 sm:grid-cols-2">
                <div>
                    <label for="region" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Wilayah</label>
                    <select id="region" name="region" class="field-input mt-1.5 <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r->value); ?>" <?php if(old('region', $fish->region?->value) === $r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('partials.field-error', ['name' => 'region'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div>
                    <label for="rarity" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Kelangkaan</label>
                    <select id="rarity" name="rarity" class="field-input mt-1.5 <?php $__errorArgs = ['rarity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__currentLoopData = $rarities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r->value); ?>" <?php if(old('rarity', $fish->rarity?->value) === $r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('partials.field-error', ['name' => 'rarity'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>

            <div>
                <label for="description" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Deskripsi</label>
                <textarea id="description" name="description" rows="4" class="field-input mt-1.5 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description', $fish->description)); ?></textarea>
                <?php echo $__env->make('partials.field-error', ['name' => 'description'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <?php if($fish->photoUrl()): ?>
                <div>
                    <p class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Foto saat ini</p>
                    <img src="<?php echo e($fish->photoUrl()); ?>" alt="Foto <?php echo e($fish->name); ?>" class="mt-2 max-h-64 rounded-md object-cover">
                </div>
            <?php endif; ?>

            <div>
                <label for="image" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Unggah foto (JPG, PNG, atau WebP; maks. 5 MB)</label>
                <input id="image" type="file" name="image" accept="image/jpeg,image/png,image/webp" class="field-input mt-1.5 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo $__env->make('partials.field-error', ['name' => 'image'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div>
                <label for="image_url" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Atau tautan foto (opsional)</label>
                <input id="image_url" type="url" name="image_url" value="<?php echo e(old('image_url', filter_var($fish->image_url, FILTER_VALIDATE_URL) ? $fish->image_url : '')); ?>" placeholder="https://…" class="field-input mt-1.5 <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo $__env->make('partials.field-error', ['name' => 'image_url'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <?php if($editing && $fish->image_url): ?>
                <label class="flex items-center gap-2 text-sm text-grey-700">
                    <input type="checkbox" name="remove_image" value="1" <?php if(old('remove_image')): echo 'checked'; endif; ?>>
                    Hapus foto yang tersimpan saat ini
                </label>
            <?php endif; ?>

            <button type="submit" class="btn-primary w-full sm:w-auto sm:px-12"><?php echo e($editing ? 'Simpan perubahan' : 'Tambah ikan'); ?></button>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/admin/fish/form.blade.php ENDPATH**/ ?>