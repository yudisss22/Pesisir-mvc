<nav class="mb-5 flex flex-wrap gap-2" aria-label="Menu admin">
    <?php $__currentLoopData = [['admin.dashboard', 'Ringkasan'], ['admin.users.index', 'Pengguna'], ['admin.catch-logs.index', 'Tangkapan'], ['admin.fish.index', 'Katalog ikan']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route($route)); ?>" <?php if(request()->routeIs($route === 'admin.dashboard' ? $route : explode('.', $route)[0].'.'.explode('.', $route)[1].'.*')): ?> aria-current="page" <?php endif; ?>
           class="rounded-full px-5 py-2 text-sm font-extrabold shadow-card <?php echo e(request()->routeIs($route === 'admin.dashboard' ? $route : explode('.', $route)[0].'.'.explode('.', $route)[1].'.*') ? 'bg-navy-900 text-white' : 'bg-white text-grey-600'); ?>"><?php echo e($label); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/admin/subnav.blade.php ENDPATH**/ ?>