<?php $__env->startSection('heading', 'Laporan pesisir'); ?>
<?php $__env->startSection('subtitle', 'Tinjau laporan kondisi pesisir yang dikirim pengguna — cari dan saring berdasarkan kategori, tingkat, status, dan lokasi.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="glass-card p-6">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <h2 class="font-serif text-2xl font-bold">Daftar laporan</h2>
                <p class="mt-1 text-sm text-grey-600"><?php echo e($reports->total()); ?> laporan ditemukan.</p>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('laporan.create')); ?>" class="btn-primary text-sm">+ Buat laporan</a>
            <?php else: ?>
                <a href="<?php echo e(route('auth')); ?>" class="btn-ghost text-sm">Masuk untuk membuat laporan</a>
            <?php endif; ?>
        </div>

        <form method="GET" action="<?php echo e(route('laporan.index')); ?>" class="mt-5 grid gap-3 md:grid-cols-6">
            <div class="md:col-span-2">
                <label for="f-q" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Cari</label>
                <input id="f-q" type="search" name="q" value="<?php echo e($filters['q']); ?>" placeholder="Judul atau isi laporan…" class="field-input mt-1.5">
            </div>
            <div>
                <label for="f-kategori" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Kategori</label>
                <select id="f-kategori" name="kategori" class="field-input mt-1.5">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->value); ?>" <?php if($filters['category'] === $c->value): echo 'selected'; endif; ?>><?php echo e($c->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label for="f-tingkat" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Tingkat</label>
                <select id="f-tingkat" name="tingkat" class="field-input mt-1.5">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $severities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->value); ?>" <?php if($filters['severity'] === $s->value): echo 'selected'; endif; ?>><?php echo e($s->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label for="f-status" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Status</label>
                <select id="f-status" name="status" class="field-input mt-1.5">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->value); ?>" <?php if($filters['status'] === $s->value): echo 'selected'; endif; ?>><?php echo e($s->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label for="f-lokasi" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Lokasi</label>
                <select id="f-lokasi" name="lokasi" class="field-input mt-1.5">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($l->id); ?>" <?php if($filters['location_id'] === $l->id): echo 'selected'; endif; ?>><?php echo e($l->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="flex gap-2 md:col-span-6">
                <button type="submit" class="btn-primary px-8 text-sm">Terapkan</button>
                <?php if($hasFilter): ?>
                    <a href="<?php echo e(route('laporan.index')); ?>" class="btn-ghost text-sm">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        <?php if($reports->isEmpty()): ?>
            <p class="mt-6 rounded-md bg-sky-50 p-6 text-center text-sm text-grey-600">
                <?php echo e($hasFilter ? 'Tidak ada laporan yang cocok dengan filter.' : 'Belum ada laporan.'); ?>

            </p>
        <?php else: ?>
            <ul class="mt-6 space-y-3">
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('laporan.show', $r)); ?>" class="block rounded-md border border-grey-100 bg-white p-4 hover:border-blue-500">
                            <div class="flex flex-wrap items-start justify-between gap-2">
                                <p class="text-base font-extrabold"><?php echo e($r->title); ?></p>
                                <div class="flex flex-wrap gap-1.5">
                                    <span class="rounded-full px-3 py-0.5 text-xs font-extrabold <?php echo e($r->severity->badgeClass()); ?>"><?php echo e($r->severity->label()); ?></span>
                                    <span class="rounded-full px-3 py-0.5 text-xs font-extrabold <?php echo e($r->status->badgeClass()); ?>"><?php echo e($r->status->label()); ?></span>
                                </div>
                            </div>
                            <p class="mt-1 text-sm text-grey-600"><?php echo e(\Illuminate\Support\Str::limit($r->description, 140)); ?></p>
                            <p class="mt-2 text-xs text-grey-400">
                                <?php echo e($r->category->label()); ?> · <?php echo e($r->location->name); ?> · oleh <?php echo e($r->user?->name ?? 'pengguna terhapus'); ?> · <?php echo e($r->created_at->diffForHumans()); ?>

                            </p>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php echo e($reports->links()); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/laporan/index.blade.php ENDPATH**/ ?>