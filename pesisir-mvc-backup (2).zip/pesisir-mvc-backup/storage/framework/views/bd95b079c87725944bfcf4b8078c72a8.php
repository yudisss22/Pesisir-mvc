<?php $__env->startSection('heading', 'Informasi ketersediaan ikan'); ?>
<?php $__env->startSection('subtitle', 'Lihat ikan yang sering dijumpai di wilayah pilihanmu, lengkap dengan tingkat kelangkaannya, dan catat hasil tangkapanmu di sini.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="glass-card p-6">
        <h2 class="font-serif text-2xl font-bold">Ketersediaan ikan per wilayah</h2>
        <p class="mt-1 text-sm text-grey-600">Pilih wilayah penangkapan untuk melihat ikan yang sering dijumpai beserta tingkat kelangkaannya.</p>

        <div class="mt-4 flex flex-wrap gap-2" role="group" aria-label="Pilih wilayah">
            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('ikan.index', ['wilayah' => $r->value])); ?>" <?php if($region === $r->value): ?> aria-current="true" <?php endif; ?>
                   class="rounded-full border px-4 py-2 text-sm font-extrabold <?php echo e($region === $r->value ? 'border-navy-900 bg-navy-900 text-white' : 'border-grey-100 bg-white text-grey-400'); ?>"><?php echo e($r->label()); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <form method="GET" action="<?php echo e(route('ikan.index')); ?>" class="mt-4 flex max-w-md gap-2">
            <input type="hidden" name="wilayah" value="<?php echo e($region); ?>">
            <label for="fish-q" class="sr-only">Cari nama ikan</label>
            <input id="fish-q" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama ikan…" class="field-input">
            <button type="submit" class="btn-ghost flex-none px-5">Cari</button>
        </form>

        <?php if($fish->isEmpty()): ?>
            <p class="py-10 text-center text-sm text-grey-600"><?php echo e($q ? 'Tidak ada ikan yang cocok dengan pencarian.' : 'Belum ada data ikan untuk wilayah ini.'); ?></p>
        <?php else: ?>
            <ul class="mt-5 grid gap-4 md:grid-cols-2">
                <?php $__currentLoopData = $fish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <article class="rounded-md border border-grey-100 bg-white p-4">
                            <a href="<?php echo e(route('ikan.index', ['wilayah' => $region, 'ikan' => $f->name])); ?>#catat"
                               class="flex w-full items-start gap-4 text-left hover:text-blue-600"
                               aria-label="<?php echo e($f->name); ?>, <?php echo e($f->rarity->label()); ?>. Pilih untuk dicatat.">
                                <span class="flex h-20 w-20 flex-none items-center justify-center overflow-hidden rounded-md bg-gradient-to-br from-blue-100 to-teal-100 text-3xl" aria-hidden="true">
                                    <?php if($f->photoUrl()): ?>
                                        <img src="<?php echo e($f->photoUrl()); ?>" alt="Foto <?php echo e($f->name); ?> di wilayah <?php echo e($f->region->label()); ?>" class="h-full w-full object-cover" loading="lazy">
                                    <?php else: ?>
                                        🐟
                                    <?php endif; ?>
                                </span>
                                <span class="min-w-0 flex-1">
                                    <span class="flex items-start justify-between gap-2">
                                        <span class="text-base font-extrabold"><?php echo e($f->name); ?></span>
                                        <span class="flex-none rounded-full px-3 py-0.5 text-xs font-extrabold <?php echo e($f->rarity->badgeClass()); ?>"><?php echo e($f->rarity->label()); ?></span>
                                    </span>
                                    <span class="mt-1 line-clamp-2 block text-sm text-grey-600"><?php echo e($f->description); ?></span>
                                    <span class="mt-2 block text-xs font-bold text-blue-600">Pilih untuk mencatat tangkapan</span>
                                </span>
                            </a>
                            <details class="mt-3 border-t border-grey-100 pt-3">
                                <summary class="cursor-pointer text-sm font-extrabold text-blue-600">Tampilkan selengkapnya</summary>
                                <dl class="mt-3 grid gap-3 text-sm sm:grid-cols-2">
                                    <div class="sm:col-span-2">
                                        <dt class="font-bold text-grey-700">Deskripsi</dt>
                                        <dd class="mt-1 whitespace-pre-line text-grey-600"><?php echo e($f->description); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="font-bold text-grey-700">Wilayah</dt>
                                        <dd class="mt-1 text-grey-600"><?php echo e($f->region->label()); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="font-bold text-grey-700">Tingkat kelangkaan</dt>
                                        <dd class="mt-1 text-grey-600"><?php echo e($f->rarity->label()); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="font-bold text-grey-700">Ditambahkan</dt>
                                        <dd class="mt-1 text-grey-600"><?php echo e($f->created_at->format('d M Y, H:i')); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="font-bold text-grey-700">Terakhir diperbarui</dt>
                                        <dd class="mt-1 text-grey-600"><?php echo e($f->updated_at->format('d M Y, H:i')); ?></dd>
                                    </div>
                                </dl>
                                <?php if($f->photoUrl()): ?>
                                    <img src="<?php echo e($f->photoUrl()); ?>" alt="Foto <?php echo e($f->name); ?>" class="mt-3 max-h-72 rounded-md object-cover" loading="lazy">
                                <?php else: ?>
                                    <p class="mt-3 text-sm text-grey-600">Belum ada foto untuk jenis ikan ini.</p>
                                <?php endif; ?>
                            </details>
                        </article>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </section>

    <section id="riwayat" class="glass-card mt-5 p-6">
        <h2 class="font-serif text-2xl font-bold">Riwayat penangkapan</h2>
        <p class="mt-1 text-sm text-grey-600">Catat ikan yang berhasil kamu tangkap — riwayat ini membantu melihat pola tangkapan dari waktu ke waktu.</p>

        <p class="mt-1 text-sm text-grey-600">Riwayat dan foto ditampilkan sesuai wilayah yang dipilih: <?php echo e(\App\Enums\Region::from($region)->label()); ?>.</p>
        <form id="catat" method="POST" action="<?php echo e(route('tangkapan.store')); ?>" enctype="multipart/form-data" novalidate class="mt-4 max-w-xl">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="region" value="<?php echo e($region); ?>">
            <div>
                <label for="fish_name" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Jenis ikan</label>
                <input id="fish_name" type="text" name="fish_name" value="<?php echo e(old('fish_name', $prefillFish)); ?>" placeholder="Contoh: Tenggiri"
                       class="field-input mt-1.5 <?php $__errorArgs = ['fish_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo $__env->make('partials.field-error', ['name' => 'fish_name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mt-4">
                <label for="quantity" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Jumlah / berat</label>
                <input id="quantity" type="text" name="quantity" value="<?php echo e(old('quantity')); ?>" placeholder="Contoh: 5 kg atau 12 ekor"
                       class="field-input mt-1.5 <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php echo $__env->make('partials.field-error', ['name' => 'quantity'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mt-4">
                <label for="note" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Catatan (opsional)</label>
                <textarea id="note" name="note" rows="3" placeholder="Contoh: Didapat dari tengah laut, air sedang tinggi dan ombak besar"
                          class="field-input mt-1.5 <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('note')); ?></textarea>
                <?php echo $__env->make('partials.field-error', ['name' => 'note'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mt-4">
                <label for="catch-image" class="block text-xs font-extrabold uppercase tracking-wide text-grey-700">Foto ikan / tangkapan (opsional, maks. 5 MB)</label>
                <input id="catch-image" type="file" name="image" accept="image/jpeg,image/png,image/webp"
                       class="field-input mt-1.5 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <p class="mt-1 text-xs text-grey-600">Jika jenis ikan belum ada, foto akan membuat data katalog ikan untuk wilayah ini. Jika data sudah ada tanpa foto, foto ini akan ditambahkan. Foto katalog dapat ditinjau dan diubah oleh admin.</p>
                <?php echo $__env->make('partials.field-error', ['name' => 'image'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <button type="submit" class="btn-primary mt-5 w-full sm:w-auto sm:px-12">Catat tangkapan</button>
            <?php else: ?>
                <a href="<?php echo e(route('auth')); ?>" class="btn-primary mt-5 w-full sm:w-auto sm:px-12">Masuk untuk mencatat</a>
            <?php endif; ?>
        </form>

        <?php if(auth()->guard()->check()): ?>
            <div class="mt-6">
                <h3 class="text-sm font-extrabold">Catatan saya</h3>
                <?php if($logs->isEmpty()): ?>
                    <p class="mt-2 rounded-md bg-sky-50 p-4 text-sm text-grey-600">Belum ada catatan. Catat tangkapan pertamamu di atas.</p>
                <?php else: ?>
                    <ul class="mt-2 space-y-2">
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-start justify-between gap-3 rounded-md border border-grey-100 bg-white p-3">
                                <div class="min-w-0">
                                    <p class="text-sm font-extrabold"><?php echo e($log->fish_name); ?> <span class="font-semibold text-grey-600">· <?php echo e($log->quantity); ?></span></p>
                                    <?php if($log->note): ?>
                                        <p class="mt-0.5 text-sm text-grey-600"><?php echo e($log->note); ?></p>
                                    <?php endif; ?>
                                    <?php if($log->image_path): ?>
                                        <img src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($log->image_path)); ?>" alt="Foto tangkapan <?php echo e($log->fish_name); ?>" class="mt-2 max-h-48 rounded-md object-cover">
                                    <?php endif; ?>
                                    <p class="mt-0.5 text-xs text-grey-400"><?php echo e($log->created_at->diffForHumans()); ?></p>
                                </div>
                                <form method="POST" action="<?php echo e(route('tangkapan.destroy', $log)); ?>" data-confirm="Hapus catatan <?php echo e($log->fish_name); ?> ini?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-danger">Hapus</button>
                                </form>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php echo e($logs->fragment('riwayat')->links()); ?>

                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pesisir-mvc-backup\resources\views/ikan/index.blade.php ENDPATH**/ ?>