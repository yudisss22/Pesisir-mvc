<?php

namespace App\Http\Controllers;

use App\Enums\Region;
use App\Models\Fish;
use App\Support\CurrentLocation;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Informasi ketersediaan ikan per wilayah (publik) + riwayat tangkapan milik pengguna. */
class FishController extends Controller
{
    public function __construct(private readonly CurrentLocation $current)
    {
    }

    public function index(Request $request): View
    {
        $user = $request->user();
        // Wilayah awal mengikuti lokasi aktif (default Jawa).
        $region = $this->enumFilter($request->query('wilayah'), Region::class)
            ?? ($this->current->get()?->region->value ?? Region::JAWA->value);
        $q = $this->textFilter($request->query('q'));

        $fish = Fish::query()
            ->search($q, $region)
            ->orderByRaw("FIELD(rarity, 'UMUM', 'CUKUP_UMUM', 'JARANG', 'SANGAT_JARANG')")
            ->orderBy('name')
            ->get();

        $logs = $user
            ? $user->catchLogs()->where('region', $region)
                ->latest()->orderByDesc('id')->paginate(5, ['*'], 'riwayat')->withQueryString()
            : null;

        return view('ikan.index', [
            'regions' => Region::cases(),
            'region' => $region,
            'q' => $q,
            'fish' => $fish,
            'logs' => $logs,
            'prefillFish' => $this->textFilter($request->query('ikan')),
        ]);
    }
}
